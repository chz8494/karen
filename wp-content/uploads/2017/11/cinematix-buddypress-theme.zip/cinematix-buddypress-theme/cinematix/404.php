<?php get_header(); ?>

	<div id="content">

	<div class="page-title-bold"><?php esc_html_e('Not Found', 'cinematix'); ?></div>

	<p><?php esc_html_e( 'It looks like nothing was found at this location.', 'cinematix' ); ?></p>

	</div><!-- #content -->

<?php get_footer(); ?>

