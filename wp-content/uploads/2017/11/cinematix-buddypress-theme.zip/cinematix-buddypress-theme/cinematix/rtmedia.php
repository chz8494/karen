<?php get_header(); ?>

<div id="content">

<?php the_content(); ?>

</div><!-- #item-body -->
</div><!-- #content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>
